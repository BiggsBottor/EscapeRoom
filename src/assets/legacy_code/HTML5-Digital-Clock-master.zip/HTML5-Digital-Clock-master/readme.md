#HTML5 Alarm Clock#

A quick demo of an Alarm Clock. Put together so I could have a play with Canvas element.

Feel free to play about with it.

Copyright (C) 2011 Richard Pullinger